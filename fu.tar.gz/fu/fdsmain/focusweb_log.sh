#!/bin/bash -

tail -f /var/log/ca/FM_LOG.log | logger -p local0.info -i 

